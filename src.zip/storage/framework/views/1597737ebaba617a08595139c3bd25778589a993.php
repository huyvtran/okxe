<?php $__env->startSection('content'); ?>

<div class="container" >

    <div class="row">
        <!--box header-->
        <div class="box-header">
              <h3 class="box-title"><a href="<?php echo e(route('admin.items.dashboard')); ?>">Administrator</a> > <b>Items</b></h3>
            </div>
        <div class="col-md-12" style="margin-top:30px;">
          
          <div class="box">            
            <!--end box header-->
            <!--box body-->
            <div class="box-body" style="background:white;">
              <form action="<?php echo e(route('admin.items.bulkupdate')); ?>" method="post" class="form-inline" style="margin-top:30px;background:white;">
                  <?php echo e(csrf_field()); ?>

                  <!--alert-->
                  <?php if(session('alert')): ?>
                      <div id="message" class="alert alert-success"><?php echo e(session('alert')); ?></div>
                  <?php endif; ?>
                  <!--end alert-->
                  <!--Table-->
                  <table id="myTable" cellpadding="0" cellspacing="0" border="0" class="table table-bordered table-striped" width="100%">
                      <thead class="">
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Location</th>
                            <th>Registration no.</th>
                            <th>Price (đ)</th>
                            <th>Status</th>
                            <th>Date/time</th>
                            <th><input type="checkbox" id="options" style="margin-left:-7px;"></th>
                        </tr>
                      </thead>
                      <thead>
                        <tr>
                        <td width="10%"><input type="text" data-column="0" style="width:100% !important;"  class="search-input-text form-control"></td>
                        <td width="13%"><input type="text" data-column="1"  style="width:100% !important;" class="search-input-text form-control"></td>
                        
                        <td width="13%">
                            <select data-column="2"  class="search-input-select form-control" style="width:100% !important;">
                            <option value="">(Select a city)</option>
                            <?php foreach($cities as $city): ?>
                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                            <?php endforeach; ?>
                            </select>
                        </td>

                        <td width="5%"><input type="text" data-column="3" style="width:100% !important;"  class="search-input-text form-control"></td>
                        <td width="10%"><input type="text" data-column="4" style="width:100% !important;"  class="search-input-text form-control"></td>

                        <td width="8%">
                            <select data-column="5"  class="search-input-select form-control" style="width:100% !important;">
                            <option value="">(Select a status)</option>
                            
                            <?php foreach($statuses as $key=>$value): ?>
                            <option value="<?php echo e($value); ?>"><?php echo e($value); ?>

                            </option>
                            <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <input type="text" data-column="6" id="dayFrom" placeholder="From"  class="search-input-date form-control">
                            <input type="text" data-column="6" id="dayTo" placeholder="To" class="search-input-date form-control">
                        </td>
                        <td></td>
                        </tr>
                      </thead>
                
                  </table>
                  <!--end table-->
                  <!--Change status-->    
                  <div class="form-group" style="float:right;position:relative;top:-30px;right:-165px"> 
                    <div class="col-md-12">Change (selected items) status to</div>
                      <select name="checkBoxes" id="" class="form-control" style="margin-left:15px;">
                        <?php foreach($statuses as $key=>$value): ?>
                        <option value="<?php echo e($value); ?>"><?php echo e($value); ?>

                        </option>
                        <?php endforeach; ?>
                      </select>
                      <input type="submit" class="btn btn-success" value="Submit">
                    </div>
                  </div>
                  <!--end sttus-->
              </form>
            </div>
            <!--end box body-->
          </div>

        </div>

    </div>   

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>

$(document).ready(function(){
  $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });

  var dataTable = $('#myTable').DataTable( {
    "autoWidth": false,
    "processing": true,
    "sDom": 'Rlfrtip',
    "columnDefs": [ {
      "targets": 7,
      "orderable": false
      }
       ],
      columns: [
      { data: "id" , "width" : "9%" }, 
      { data: "title" , "width" : "18%" }, 
      { data: "id_province","width" : "18%"  },
      { data: "seri","width" : "15%" },  
      { data: "price" ,"width" : "13%"},
      { data: "status" , "width":"16%" }, 
      { data: "created_at", "width":"23%" }, 
      { data: "checkbox","width" : "8%"}, 
    ],
    "serverSide": true,
    "ajax":{
      url :"<?php echo e(route('admin.getlist')); ?>", 
      type: "post",  
      error: function(){  
        $(".myTable-error").html("");
        $("#myTable").append('<tbody class="myTable-error"><tr><th colspan="8" style="background:white;">Whoops, looks like something went wrong.</th></tr></tbody>');
        $("#myTable_processing").css("display","none");
        
      }
    }
  } );
  $("#myTable_filter").css("display","none");  // hiding global search box
  $('.search-input-text').on( 'blur', function () {   // for text boxes
    var i =$(this).attr('data-column');  // getting column index
    var v =$(this).val();  // getting search input value
    dataTable.columns(i).search(v).draw();
  } );
  $('.search-input-date').on( 'change', function () {   // for date boxes
    var i =$(this).attr('data-column');  // getting column index
    var v =$("#dayFrom").val() + '-' +$("#dayTo").val();  // getting search input value
    dataTable.columns(i).search(v).draw();
  } );
  $('.search-input-select').on( 'change', function () {   // for select box
    var i =$(this).attr('data-column');  
    var v =$(this).val();  
    dataTable.columns(i).search(v).draw();
  } );
});


jQuery(document).ready(function(e) {
    jQuery('#dayFrom').datepicker({
		format:'DD/MM/YYYY'
	});
	jQuery('#dayTo').datepicker({
		format:'DD/MM/YYYY'
	});
});

$(document).ready(function(){
  $('#options').click(function(){
    if(this.checked){
      $('.checkBoxes').each(function(){
        this.checked = true;
      });
    }else{
      $('.checkBoxes').each(function(){
        this.checked = false;
      });
    }
 
  });

$(function() {
  setTimeout(function() {
      $("#message").hide('blind', {}, 500)
  }, 4000);
});
 

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>