<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
        <!--box header-->
        <div class="box-header">
              <h3 class="box-title"><a href="<?php echo e(route('admin.items.dashboard')); ?>">Administrator</a> > <b>Items</b></h3>
            </div>
<?php if(session('alert')): ?>
                   <div class="alert alert-success"><?php echo e(session('alert')); ?></div>
               <?php endif; ?>
    <div class="status">
      <h4><span class="adItemPostedTime"><?php echo e($item->province->name); ?></span> <span class=" "> | <a href=""></--><?php echo e($item->user->name); ?></a></span><span class="item"> | <b></--><?php echo e($item->title); ?></b></span></h4>
    
   <hr style="height:2px;border:none;color:#333;background-color:#333;" /> 
</div>   
    <div class="row">
      <div class="col-md-4" >
        <h5 style="margin-left: 40px;"><tr ><?php echo e($item->type); ?>, <?php echo e($item->color); ?>,<?php echo e($item->engine_power); ?> </tr></h5>
        <ul class="text-justify">
            <b><h3 style="color: red; font-size: 40px"><tr><?php echo e(number_format($item->price,"0",",",".")); ?> đ</tr></h3></b>
           <tr> <b style="font-size: 22px"><?php echo e($item->seri); ?></b>   &nbsp &nbsp (<?php echo e($item->year); ?>)</tr><br>
            <b style="font-size: 20px"><tr><?php echo e($item->number); ?> km, 99% new</tr></b><br>
            <tr>Last maintenance: <?php echo $item->updated_at->diffForHumans(); ?></tr><br>
            <tr>Ower:<?php echo e($item->user->name); ?></tr>


        </ul>
      </div><!--col-md-4-->
      <div class="col-md-8" >
        <form action="<?php echo e(route('admin.items.update',$item->id)); ?>" method="POST">
           <?php echo e(csrf_field()); ?>

        
          <div class="btn-group" role="group">
            <select name="status" id="" class="form-control">
             <?php foreach($item->statuses as $status): ?>
                <option value="<?php echo e($status); ?>" <?php echo e($item->status == $status ? 'selected' : ''); ?>><?php echo e($status); ?></option>
             <?php endforeach; ?>
            </select>
          </div>
          <input type="submit" value="Update status">
        </form>
        <br>
        <b><h4><tr>Descripttion :</tr></h4></b>

        <tr><?php echo e($item->description); ?></tr>

      </div><!--col-md-8-->

    </div>
    <hr>
    <div class="container"  >
   
       <div class="row">
       <?php if($item->images): ?>
      <?php foreach($item->images as $image): ?>
     <div class="col-md-3 col-sm-6 col-xs-6">
-          <div class="product_box thumbnail picture_sp">
        <img src="<?php echo e(url('/public/images')); ?>/<?php echo e($image->name); ?>" alt="">
         </div>
      </div>           
      <?php endforeach; ?>
  
      <?php endif; ?>
      </div>
       <div class="map">
       <div>
           <iframe
               width="1003px"
               height="500px"
               frameborder="0" style="border:0"
               src="https://www.google.com/maps/embed/v1/place?key=<?php echo e(env('GOOGLE_MAP_KEY')); ?>

               &q=<?php echo e($item->ward->name); ?>" allowfullscreen>
           </iframe>      
       </div>
     </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>