<div class="margin_30_top">
    <p class="bold"><?php echo e(trans('label.provinces')); ?> <?php echo e(trans('label.w_items')); ?></p>
    <div id="list_item_okxe">            
        <table cellpadding="0" cellspacing="0" border="0" class="staTable table table-bordered with100percent">
            <thead>
                <tr>
                    <tr>
                        <th><?php echo e(trans('label.name')); ?></th>
                        <th><?php echo e(trans('label.total')); ?></th>
                        <th><?php echo e(trans('label.active')); ?></th>
                    </tr>
                </tr>
            </thead>
            <tbody>
                <?php foreach($data[0] as $province): ?>
                <tr>
                    <td><?php echo e($province->name); ?></td>
                    <td><?php echo e($province->total); ?></td>
                    <td><?php echo e($province->active); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="margin_30_top">
    <p class="bold"><?php echo e(trans('label.brands')); ?> <?php echo e(trans('label.w_items')); ?></p>
    <div id="list_item_okxe">            
        <table cellpadding="0" cellspacing="0" border="0" class="staTable table table-bordered table-dark with100percent">
            <thead>
                <tr>
                    <tr>
                        <th><?php echo e(trans('label.name')); ?></th>
                        <th><?php echo e(trans('label.total')); ?></th>
                        <th><?php echo e(trans('label.active')); ?></th>
                    </tr>
                </tr>
            </thead>
            <tbody>
                <?php foreach($data[1] as $brand): ?>
                <tr>
                    <td><?php echo e($brand->name); ?></td>
                    <td><?php echo e($brand->total); ?></td>
                    <td><?php echo e($brand->active); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="margin_30_top">
    <p class="bold"><?php echo e(trans('label.models')); ?> <?php echo e(trans('label.w_items')); ?></p>
    <div id="list_item_okxe">            
        <table class="staTable table table-bordered table-dark with100percent">
            <thead>
                <tr>
                    <th><?php echo e(trans('label.name')); ?></th>
                    <th><?php echo e(trans('label.total')); ?></th>
                    <th><?php echo e(trans('label.active')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($data[2] as $model): ?>
                <tr>
                    <td><?php echo e($model->name); ?>(<?php echo e($model->bname); ?>)</td>
                    <td><?php echo e($model->total); ?></td>
                    <td><?php echo e($model->active); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="margin_30_top padding_30_bottom">
    <p class="bold"><?php echo e(trans('label.accounts')); ?> <?php echo e(trans('label.w_items')); ?></p>
    <div id="list_item_okxe">            
        <table cellpadding="0" cellspacing="0" border="0" class="staTable table table-bordered table-striped with100percent">
            <thead>
                <tr>
                    <tr>
                        <th><?php echo e(trans('label.name')); ?></th>
                        <th><?php echo e(trans('label.total')); ?></th>
                        <th><?php echo e(trans('label.active')); ?></th>
                    </tr>
                </tr>
            </thead>
            <tbody>
                <?php foreach($data[3] as $account): ?>
                <tr>
                    <td><a target="_blank" href="<?php echo e(route('admin.accounts.detail',$account->id)); ?>"><?php echo e($account->name); ?></a></td>
                    <td><?php echo e($account->total); ?></td>
                    <td><?php echo e($account->active); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    $('.staTable').DataTable();
</script>