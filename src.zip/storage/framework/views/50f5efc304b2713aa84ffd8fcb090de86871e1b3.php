<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="box-header-detail">
       <h3 class="box-title"><a href="<?php echo e(route('admin.items.dashboard')); ?>"><?php echo e(trans('label.administrator')); ?></a>  > <b><?php echo e(trans('label.items')); ?></b></h3>
      <h4><span><?php echo e($item->province ? $item->province->name.' | ' : ''); ?></span> <span><a href="<?php echo e(route('admin.accounts.detail',$item->user ? $item->user->id : '')); ?>"> <?php echo e($item->user ? $item->user->name.' | ' : ''); ?></a></span> <span class="bold_words"><?php echo e($item->title ? $item->title:''); ?></span></h4>
      <hr class="hr"/> 
  </div> <!-- box-header -->

      <?php if(session('alert')): ?>
        <div id="message" class="alert alert-success"><?php echo e(session('alert')); ?></div>
      <?php endif; ?>
    <div class="body_detail col-md-12">
        <div class="col-md-4">
            <?php echo e($item->type ? ($item->type.($item->color || $item->engine_power?',' :'')): ''); ?> <?php echo e($item->color ? $item->color.($item->engine_power?',' :''):''); ?> <?php echo e($item->engine_power); ?> 
            <h3 class="price"><?php echo e(number_format($item->price,"0",",",".")); ?> <?php echo e(trans('label.currency')); ?> </h3>
            <span class="bold_words"><?php echo e($item->seri); ?></span>
              <?php echo e($item->year ? '('.$item->year.')' : ''); ?> 
            <p class="bold_words"><?php echo e($item->number ? trans('label.km',['km'=>$item->number]).($item->quality_color ? ',' : '') : ''); ?>  <?php echo e($item->quality_color ? trans('label.quality',['quality'=>$item->quality_color]) : ''); ?></p> 
            <p><?php echo e($item->user ? trans('label.owner').':' : ''); ?> <?php echo e($item->user ? $item->user->name : ''); ?></p>
        </div> <!-- col-md-4 -->

        <div class="col-md-8" >
            <form action="<?php echo e(route('admin.items.update',$item->id)); ?>" method="POST">
           <?php echo e(csrf_field()); ?>

        
            <div class="btn-group" role="group">
              <select name="status" id="" class="form-control">
                <?php foreach($item->statuses as $status): ?>
                  <option value="<?php echo e($status); ?>" <?php echo e($item->status == $status ? 'selected' : ''); ?>><?php echo e($status); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
              <input class="btn btn-success" type="submit" value="<?php echo e(trans('label.update_status')); ?>">
            </form>
          <br>
             <p class="bold_words"><?php echo e(trans('label.descripttion')); ?> :</p>
             <div><?php echo e($item->description ? $item->description: ''); ?></div>
        </div> <!-- col-md-8 -->
    </div> <!-- body_detail -->
    
  <div class="col-md-12">
     <?php if($item->images): ?>
       <?php foreach($item->images as $image): ?>
          <div class="col-md-3 col-sm-6 col-xs-6">
            <img class="thumb" src="<?php echo e(url('/public/images')); ?>/<?php echo e($image->name); ?>" alt="">           
          </div>           
       <?php endforeach; ?>  
     <?php endif; ?>
  </div col-md-12> <!-- images -->
  <iframe class="map col-md-12 col-sm-12 col-xs-12"
            src="https://www.google.com/maps/embed/v1/place?key=<?php echo e(env('GOOGLE_MAP_KEY')); ?>

            &q=<?php echo e($item->ward ? $item->ward->name : ($item->county ? $item->county->name : ($item->province ? $item->province->name : 'Việt Nam'))); ?>" allowfullscreen>
  </iframe> 
</div> <!-- container -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
$(function() {
  setTimeout(function() {
      $("#message").hide('blind', {}, 500)
  }, 4000);
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>