<?php 
return [
    'processing' => 'Đang xử lý...',
    'empty_table' => 'Không có bản ghi',
    'show' => 'Hiển thị',
    'record' => 'bản ghi',
    'first' => 'Đầu',
    'last' => 'Cuối',
    'next' => 'Tiếp',
    'prev' => 'Trước',
    'filtered' => 'Được lọc từ',
    'no_record' => 'Không có bản ghi nào được tìm thấy'
];